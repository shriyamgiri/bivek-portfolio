package com.example.hexaware.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.example.hexaware.jdbc.connection.ConnectionProperties;

public class StudentMain {
	
	private static Connection connection;
	private static Scanner input = new Scanner(System.in);
	
	/*
	 * Important steps to connect to JDBC 
	 * 
	 * 1) Load and Register the Driver
	 * 2) Establish the connection
	 * 3) Create platform to execute the query
	 * 4) Execute the query
	 * 5) Process the result
	 * 6) Close the connection
	 * 
	 * */
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//Register the Driver -> can throw ClassNotFoundException
		Class.forName(ConnectionProperties.DRIVER.getValue());
		
		
		//Establish The Connection: url, userName, password, throw SQLException
		String url = ConnectionProperties.URL.getValue();
		String userName = ConnectionProperties.USERNAME.getValue();
		String password = ConnectionProperties.PASSWORD.getValue();
		
		connection = DriverManager.getConnection(url,userName,password);
		
		
		System.out.println("Enter Choice:");
		System.out.println("Enter 1 To Insert Data");
		System.out.println("Enter 2 To Fetch Data");
		System.out.println("Enter 3 To Update Data");
		System.out.println("Enter 4 To Delete Data");
		
		
		int choice = input.nextInt();
		
		switch(choice) {
		case 1:
			insertData();
			break;
		case 2:
			fetchData();
			break;
		case 3:
			updateData();
			break;
		case 4:
			deleteData();
			break;
		default:
			connection.close();
		}
		
		
		
	}
	
	
	private static void insertData() throws SQLException {
		
		
		//write query
		String query = "INSERT INTO Student(name,percentage,address) VALUES(?,?,?)";
		
		//Create a platform to execute the query
		PreparedStatement ps = connection.prepareStatement(query);
		
		ps.setString(1, input.next());
		ps.setDouble(2, input.nextDouble());
		ps.setString(3, input.next());
		
		
		//Execute the query
		int rowsAffected = ps.executeUpdate(); //return number of rows affected
		
		System.out.println("Number of Rows Affected : "+rowsAffected);
		
		
		
	}
	
	private static void fetchData() throws SQLException {
		
		System.out.println("Enter Fetching Criteria");
		System.out.println("Enter 0 To Fetch All Data");
		System.out.println("Enter 1 To Fetch Data By Id");
		System.out.println("Enter 2 To Fetch Data By Name");
		System.out.println("Enter 3 To Fetch Data By Address");
		
		
		
		int choice = input.nextInt();
		
		String query = "SELECT * FROM Student";
		PreparedStatement ps;
		
		switch(choice) {
		
		case 0:
			ps = connection.prepareStatement(query);
			
			//Execute the query
			ResultSet rs0 = ps.executeQuery();
			
			while(rs0.next()) {
				
				//2-ways to get the data
				System.out.println("First Way");
				System.out.println(rs0.getInt(1)+" "+rs0.getString(2)+" "+rs0.getDouble(3)+" "+rs0.getString(4));
				
				System.out.println("Second Way");
				System.out.println(rs0.getString("percentage")+" "+rs0.getString("name")+" "+rs0.getString("address"));
				
			}
			
			
			break;
		case 1:
			query+=" WHERE id=?";
			
			ps = connection.prepareStatement(query);
			ps.setInt(1, input.nextInt());
			
			ResultSet rs1 = ps.executeQuery();
			
			while(rs1.next()) {
				
				System.out.println(rs1.getString("name")+" "+rs1.getString("address"));
				
			}
			
			break;
		case 2:
			//TODO
			break;
		case 3:
			//TODO
			break;
			
		}
		
			
	}
	private static void updateData() {
		
	}
	private static void deleteData() {
		
	}
	
	
	
	

}
