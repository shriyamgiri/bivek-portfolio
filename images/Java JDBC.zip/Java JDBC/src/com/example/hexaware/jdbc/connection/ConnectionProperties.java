package com.example.hexaware.jdbc.connection;

public enum ConnectionProperties {
	
	DRIVER("com.mysql.cj.jdbc.Driver"),
	URL("jdbc:mysql://127.0.0.1:3306/JDBC"),
	USERNAME("root"),
	PASSWORD("Apurv@1998");
	
	
	
	
	
	private String value;
	
	private ConnectionProperties(String value) {
		this.value = value;
	}
	
	
	public String getValue() {
		return this.value;
	}

}
